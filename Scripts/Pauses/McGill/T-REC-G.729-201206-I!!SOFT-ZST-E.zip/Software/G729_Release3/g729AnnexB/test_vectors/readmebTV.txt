This group of test vectors are for use with G.729 + G.729 Annex B

Usage:

Input File             Processing             Output File

tstseq1.bin            encoder                tstseq1.bit
tstseq2.bin            encoder                tstseq2.bit
tstseq3.bin            encoder                tstseq3.bit
tstseq4.bin            encoder                tstseq4.bit
tstseq1.bit            decoder                tstseq1.out
tstseq2.bit            decoder                tstseq2.out
tstseq3.bit            decoder                tstseq3.out
tstseq4.bit            decoder                tstseq4.out
tstseq5.bit            decoder                tstseq5.out
tstseq6.bit            decoder                tstseq6.out

