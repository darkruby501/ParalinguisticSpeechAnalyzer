This group of test vectors are for use with G.729 Annex A + G.729 Annex B

Usage:

Input File             Processing             Output File

tstseq1.bin            encoder                tstseq1a.bit
tstseq2.bin            encoder                tstseq2a.bit
tstseq3.bin            encoder                tstseq3a.bit
tstseq4.bin            encoder                tstseq4a.bit
tstseq1a.bit           decoder                tstseq1a.out
tstseq2a.bit           decoder                tstseq2a.out
tstseq3a.bit           decoder                tstseq3a.out
tstseq4a.bit           decoder                tstseq4a.out
tstseq5.bit            decoder                tstseq5a.out
tstseq6.bit            decoder                tstseq6a.out

